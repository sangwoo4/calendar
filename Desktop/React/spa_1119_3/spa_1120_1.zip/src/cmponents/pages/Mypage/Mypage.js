import React from "react";
export const Mypage = () =>{
    return(
        <div className="analyze">Mypage</div>
    )
}
